import json
import pickle

try:
    from urllib import unquote
except ImportError:
    from urllib.parse import unquote

with open('model_2.pkl', 'rb') as f:
    model_1 = pickle.loads(f.read())


def lambda_handler(event, context):
    a = event['queryStringParameters']['headline']
    b = unquote(a)
    pred_score = model_1.predict_proba([b])[0]

    if ((pred_score[1] * 100 > 40) & ((pred_score[1] * 100 < 60))):
        tag = 'Not Sure'
        color = 'is-warning'
    elif (pred_score[1] * 100 > 60):
        tag = 'Baity'
        color = 'is-danger'
    else:
        tag = 'Looks Safe'
        color = 'is-primary'

    prob = {'P-clickbate': round(pred_score[1], 3), 'P-notClickbate': round(pred_score[0], 3), 'tag': tag,
            'color': color}
    print "predicted score"
    print pred_score
    print "prob"
    print prob

    return {'statusCode': 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(prob)
            }

# b = lambda_handler(0,0)

# print (b)
# https://ayqqqyltjc.execute-api.us-west-2.amazonaws.com/dev/spamDetector?headline=23+Things+You+Probably+Shouldn%27t+Say+To+Someone+With+Depression
